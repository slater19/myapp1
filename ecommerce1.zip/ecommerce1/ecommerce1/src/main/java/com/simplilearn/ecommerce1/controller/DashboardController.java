package com.simplilearn.ecommerce1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.simplilearn.ecommerce1.service.AdminService;
import com.simplilearn.ecommerce1.service.CategoryService;
import com.simplilearn.ecommerce1.service.ProductService;
import com.simplilearn.ecommerce1.service.PurchaseItemService;
import com.simplilearn.ecommerce1.service.PurchaseService;
import com.simplilearn.ecommerce1.service.UserService;




@Controller
public class DashboardController {

	  @RequestMapping("/dashboard")
	    public ModelAndView dashboard() 
	    {
		  ModelAndView mv=new ModelAndView(); 	
		  
		  mv.addObject("pageTitle", "SPORTY SHOES - DASHBOARD");
		  mv.setViewName("dashboard.jsp");
	        return mv;
	    }		  
}
