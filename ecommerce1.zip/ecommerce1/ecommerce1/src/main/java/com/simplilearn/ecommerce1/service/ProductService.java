package com.simplilearn.ecommerce1.service;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simplilearn.ecommerce1.model.Product;
import com.simplilearn.ecommerce1.model.User;
import com.simplilearn.ecommerce1.repository.AdminRepository;
import com.simplilearn.ecommerce1.repository.ProductRepository;
import java.util.List;

@Service
public class ProductService {

	 @Autowired
	 ProductRepository productRepository;


		
		public Product getProductById(long id) {
			return productRepository.findById(id).get();
		}
		
		
		
		public void updateProduct(Product product) {
			productRepository.save(product);
		}
		

		
		public void deleteProduct(long id) {
			productRepository.deleteById(id);
		}

		
		public List<Product> getAllProducts() {
			List<Product> list=new ArrayList<>();
			productRepository.findAll().forEach(product->list.add(product));
		     return list;
		}
	 
		
		
			
		
	 		
}
