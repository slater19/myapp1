package com.simplilearn.ecommerce1.service;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simplilearn.ecommerce1.model.PurchaseItem;
import com.simplilearn.ecommerce1.model.User;
import com.simplilearn.ecommerce1.repository.AdminRepository;
import com.simplilearn.ecommerce1.repository.PurchaseItemRepository;

import java.util.List;

@Service
public class PurchaseItemService {

	 @Autowired
	 PurchaseItemRepository purchaseItemRepository;

	
		public PurchaseItem getItemById(long id) {
		 return purchaseItemRepository.findById(id).get();
		
		}
		
	 
		public List<PurchaseItem> getAllItemsByPurchaseId(long purchaseId) {
			List<PurchaseItem> list=new ArrayList<>();
			purchaseItemRepository.findAll().forEach(item->list.add(item));
		     return list;
		}	
		
	 
		public void updateItem(PurchaseItem item) {
			purchaseItemRepository.save(item);
		}
		

	
		public void deleteItem(long id) {
			purchaseItemRepository.deleteById(id);
		}

	 
		public void deleteAllItemsForPurchaseId(long purchaseId) {
			purchaseItemRepository.deleteById(purchaseId);
		}


	 
}