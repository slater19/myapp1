package com.simplilearn.ecommerce1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import com.simplilearn.ecommerce1.model.PurchaseItem;
import org.springframework.stereotype.Repository;
@Repository

public interface PurchaseItemRepository extends JpaRepository<PurchaseItem, Long>{ 

	
	

	
	
	
}
