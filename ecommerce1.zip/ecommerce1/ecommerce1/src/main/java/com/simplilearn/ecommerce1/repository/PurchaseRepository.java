package com.simplilearn.ecommerce1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import com.simplilearn.ecommerce1.model.Purchase;
import org.springframework.stereotype.Repository;
@Repository
public interface PurchaseRepository extends JpaRepository<Purchase, Long> {

	

	List<Purchase> findAllByUserId(long userId);

}
