package com.simplilearn.ecommerce1.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.simplilearn.ecommerce1.model.Admin;
@Repository
public interface AdminRepository extends JpaRepository<Admin, Long>{

	Admin findByAdminIdAndPwd(String adminId, String pwd);
	
	
	

}
