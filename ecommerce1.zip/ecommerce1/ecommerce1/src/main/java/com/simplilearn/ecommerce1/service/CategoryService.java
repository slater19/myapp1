package com.simplilearn.ecommerce1.service;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simplilearn.ecommerce1.model.Category;
import com.simplilearn.ecommerce1.model.Product;
import com.simplilearn.ecommerce1.repository.AdminRepository;
import com.simplilearn.ecommerce1.repository.CategoryRepository;
import java.util.List;

@Service
public class CategoryService {

	 @Autowired
	 CategoryRepository categoryRepository;

	 
		public Category getCategoryById(long id) {
		 	return categoryRepository.findById(id).get();
		}
		
		
	 
	 public void updateCategory(Category category) {
		 categoryRepository.save(category);
		}
		

	 
	 public void deleteCategory(long id) {
		 categoryRepository.deleteById(id);
		}

	 
	 public List<Category> getAllCategories() {
		 List<Category> list=new ArrayList<>();
		 categoryRepository.findAll().forEach(category->list.add(category));
		     return list;
		}
		
	 
	 public String getCategoriesDropDown(long id) {
		 StringBuilder sb = new StringBuilder("");
		 List<Category> list = getAllCategories();
		 for(Category cat: list) {
			 if (cat.getID() == id)
				 sb.append("<option value=" + String.valueOf(cat.getID()) + " selected>" + cat.getName() + "</option>");
			 else
				 sb.append("<option value=" + String.valueOf(cat.getID()) + ">" + cat.getName() + "</option>");
				 
		 }
		 return sb.toString();
		}
		

		 
}



