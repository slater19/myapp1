package com.simplilearn.ecommerce1.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.simplilearn.ecommerce1.model.Category;
import com.simplilearn.ecommerce1.model.Product;
import com.simplilearn.ecommerce1.service.AdminService;
import com.simplilearn.ecommerce1.service.CategoryService;
import com.simplilearn.ecommerce1.service.ProductService;
import com.simplilearn.ecommerce1.service.PurchaseItemService;
import com.simplilearn.ecommerce1.service.PurchaseService;
import com.simplilearn.ecommerce1.service.UserService;




@Controller
public class HomeController {

	@Autowired
	private CategoryService categoryService; 

	@Autowired
	private ProductService productService; 
	
	  @RequestMapping(value = {"/", "/home"}, method = RequestMethod.GET)
	    public ModelAndView home() 
	    {
		    
			List<Product> list = productService.getAllProducts();
			
			// use MAP to map the category names to product rows
			 HashMap<Long, String> mapCats = new HashMap<Long, String>();
			  for(Product product: list) {
				  Category category = categoryService.getCategoryById(product.getCategoryId());
				  if (category != null)
					  mapCats.put(product.getID(), category.getName());
			  }
			ModelAndView mv=new ModelAndView();
			
			mv.addObject("list", list);
			mv.addObject("mapCats", mapCats);
		    mv.addObject("pageTitle", "SPORTY SHOES - HOMEPAGE"); 
	        mv.setViewName("index.jsp");
		    return mv; 
		    
	    }	
	    @GetMapping("/test")
	  public String testpage()
	  
	  {
		  
		  
		 return "test"; 
	  }
	  
	  
}
